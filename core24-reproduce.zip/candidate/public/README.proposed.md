# Proposed public component data projection

This directory is a reviewable, inactive preparation. No capsule verifier, archive, new test run or publication was produced in this cut.

The full expected table retains all 32 selected synthetic observations: 8 baseline and 24 mutant observations, using 2 original sources and 6 unique input byte sequences. The evidence was closed in two cuts (9 plus 23); it is not one newly executed public generation. The 32 observations are a selected design, not a cross product.

Exact unchanged source bytes are supplied for the core subset: 1 baseline plus 9 frozen mutants, 4 original public fixtures and their 24 selected observations. The remaining 8 observations stay visible in EXPECTED_SELECTED32.proposed.json. Their source is withheld because unchanged bytes contain operating coordinates. No source was rewritten to hide those coordinates.

The expected matrix is a projection of past results, not a receipt showing that this directory was executed. There is no runnable whole-bundle verify command yet. The old v1 verifier is fixed to six admission cases and cannot consume this 32-case matrix unchanged. Its code was not copied here as if it could.

All preselected mutations remain in the full denominators: behavioral detection 2/12 overall, 2/4 among positive-preserving mutants, and 2/3 conditional on valid negative observations. The conditional score must not replace the other denominators. Eight positive-breaking mutants remain visible. A MONEY diagnostic difference is not equivalence. The two ROLLBACK caught KeyError observations have source rc0 and are not process crashes or successful refusals.

The preserved upstream-v1 notices record the existing Apache-2.0 code/fixture/JSON and CC BY 4.0 documentation policy. The supplied v1.1 plan requests continuation of that policy. These upstream notices retain their original v1 scope; this preparation makes no additional rights grant, certification, standard-adoption or trademark claim. Attribution: NimadFlow (pseudonymous author), NF-SCI admission capsule public review v1, 2026. Changes here are data-only public path projections and the explicit proposed summaries; source and fixture copies are unchanged. Private correspondence is retained outside this directory.

Next is a bounded portable verifier/public motor projection proposal, followed by a separately recorded capsule build and external reproduction. These have not happened. This data projection gives no full-system autonomy, operating, trading, independent-model or natural-event credit.
