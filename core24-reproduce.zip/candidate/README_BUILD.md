# Core24 portable capsule build candidate

This is a new, unexecuted verifier candidate for a separate 24-case capsule build. It does not repeat or replace the closed original campaign. The 32 files under public/ are exact unchanged copies of an earlier preparation. Their inactive manifest, README and zero-build statements remain historical input statements; do not edit them into a success certificate.

The current command is: python -I -S -B capsule_verify.py verify --manifest-sha256 EXACT_BUILD_INPUTS_SHA256

Run from this candidate directory using an explicitly selected Python interpreter. It creates the fresh sibling execution-01 directory; an existing directory refuses the run. Root will supply the exact SHA from PREPARATION_REVIEW.json and execute only after independent review. This preparation has not run it.

Selection is exactly 24 preselected core cases: 6 baseline observations plus 18 observations of 9 already frozen mutants. All 32 original expected observations and all 12 preselected-mutant denominators remain in public/EXPECTED_SELECTED32.proposed.json. The 8 motor observations are not executed in this build. There is no full32 qualification claim.

Two results are separate. Reproduction compares new raw canonical output, ordered errors, source status, caught-error class and old grader result with the prior observation. Baseline grading compares the same new observation against the unchanged original oracle. A successful reproduction can and must reproduce an original baseline-oracle mismatch. Caught KeyError with source rc0 is reproduced as a caught component error, not a process crash or successful refusal.

Each case uses the current explicitly selected Python executable, fixed argument structure, no shell, exact copied source and fixture, and the same held empty regular stdin file. A case gets at most 5 seconds; dispatch and observation have a 60-second deadline. On a timeout only the owned direct child is killed and given up to 5 seconds to reap; cleanup may extend wall time. These exact sources spawn no descendants. The first unexpected observation stops later cases. Failed/incomplete attempts and private raw outputs are preserved; there is no retry loop.

Raw stdout/stderr/COMPONENT files and physical input identities remain in the private sibling execution directory. Unexpected raw errors are never automatically copied into public/ or printed as error text. CONTENT_RECEIPT.json excludes physical paths, identities, PID, elapsed time and incidental interpreter location. RESULT.json is the separate observation envelope. Source and fixture identities and hashes are checked before and after; whole copied input inventory is rechecked at closeout.

This is ordinary current-user portable Python reproduction, not inherited Linux r3 isolation, operating authority or independent-model qualification. No network or model call is in the verifier or the copied core sources. No upload is performed. External reproduction and publication remain unperformed.

License and attribution: this verifier is a modified derivative of the NF-SCI admission capsule v1 runner and the fixed M3 core comparison branch, NimadFlow (pseudonymous author), 2026. Changes are finite data selection, explicit stdin, bounded owned-child execution, raw evidence retention and separate reproduction/original-oracle results. The existing supplied v1.1 plan continues the upstream Apache-2.0 code/fixtures/JSON and CC BY 4.0 documentation policy; upstream notices are preserved under public/upstream-v1. No new trademark, certification or rights grant is asserted.
