"""Proposed portable core24 capsule verifier; no operating authority.

Derived from the retained v1 capsule runner and fixed M3 core grader.
Existing source/fixtures are unchanged. See README_BUILD.md and upstream-v1.
This new verifier has not inherited the old Linux namespace qualification.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PUBLIC = ROOT / "public"
OUTPUT = ROOT.parent / "execution-01"
RESULT_KEYS = {"schema", "state", "part_state", "request_sha256", "errors", "actuation_performed", "monetary_authority_present"}
FIELD_KEYS = ("label", "status", "errors", "target_error_present", "source_rc", "grader_rc", "component_error", "fixed_oracle_match")
WHOLE_SECONDS = 60.0
CASE_SECONDS = 5.0
CLEANUP_SECONDS = 5.0
FILE_CAP = 262144
STREAM_CAP = 65536
MANIFEST_KEYS = {"schema", "build_id", "mode", "case_limit", "whole_seconds", "case_seconds", "cleanup_seconds", "verifier", "public_files", "exact_labels", "full32_denominators", "status", "original_public_manifest_sha256", "source_fixture_bytes_unchanged", "full_campaign_cases", "withheld_cases", "os_profile"}
RULES = ("MONEY", "UID", "ROLLBACK")
EXACT_LABELS = [rule + "_BASELINE_" + pol for rule in RULES for pol in ("PC", "NC")]
EXACT_LABELS += [rule + "_" + op + "_" + pol for rule in RULES for op in ("DISABLE_REJECTION", "NEGATE_CONDITION", "FORCE_REJECTION") for pol in ("PC", "NC")]


class Stop(Exception):
    pass


def need(value, code):
    if not value:
        raise Stop(code)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canon(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")


def identity(st):
    return {"dev": st.st_dev, "ino": st.st_ino, "mode": st.st_mode, "nlink": st.st_nlink, "bytes": st.st_size, "mtime_ns": st.st_mtime_ns}


def safe_name(name):
    need(type(name) is str and name and not name.startswith("/") and "\\" not in name and ":" not in name, "RELATIVE_PATH")
    need(all(x not in ("", ".", "..") for x in name.split("/")), "RELATIVE_PATH")
    return name


def read_regular(path, cap=FILE_CAP):
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and not stat.S_ISLNK(before.st_mode), "NONREGULAR_INPUT")
    need(before.st_size <= cap, "INPUT_SIZE_CAP")
    with path.open("rb") as handle:
        opened = os.fstat(handle.fileno())
        need(identity(opened) == identity(before), "OPEN_IDENTITY_CHANGED")
        raw = handle.read(cap + 1)
        after = os.fstat(handle.fileno())
    need(len(raw) <= cap and identity(after) == identity(before) == identity(path.lstat()), "READ_IDENTITY_CHANGED")
    need(len(raw) == before.st_size, "READ_SIZE_CHANGED")
    return raw, identity(before)


def read_public(name):
    name = safe_name(name)
    parent = PUBLIC
    need(parent.is_dir() and not parent.is_symlink(), "PUBLIC_DIRECTORY")
    for part in name.split("/")[:-1]:
        parent = parent / part
        need(parent.is_dir() and not parent.is_symlink(), "PUBLIC_PARENT")
    return read_regular(PUBLIC / name)


def exclusive(path, raw):
    with path.open("xb") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())


def emit(path, value):
    raw = canon(value)
    exclusive(path, raw)
    return {"path": str(path.relative_to(OUTPUT)).replace("\\", "/"), "sha256": sha(raw), "bytes": len(raw)}


def snapshot(manifest):
    expected = {row["path"]: row for row in manifest["public_files"]}
    need(len(expected) == 32 and len(manifest["public_files"]) == 32, "PUBLIC_FILE_COUNT")
    actual = set()
    for path in PUBLIC.rglob("*"):
        need(not path.is_symlink(), "PUBLIC_SYMLINK")
        if path.is_file():
            actual.add(str(path.relative_to(PUBLIC)).replace("\\", "/"))
        else:
            need(path.is_dir(), "PUBLIC_SPECIAL_FILE")
    need(actual == set(expected), "PUBLIC_INVENTORY_CHANGED")
    rows = []
    for name in sorted(expected):
        row = expected[name]
        need(set(row) == {"path", "sha256", "bytes"}, "PUBLIC_PIN_SCHEMA")
        raw, ident = read_public(name)
        need(len(raw) == row["bytes"] and sha(raw) == row["sha256"], "PUBLIC_PIN_MISMATCH")
        rows.append({"path": name, "sha256": sha(raw), "bytes": len(raw), "identity": ident})
    return rows


def original_core_grade(evaluation, expected):
    # M3 fixed grader core branch, preserving issue order and comparisons.
    actual = evaluation["actual"]
    issues = []
    if evaluation["component_error"]:
        issues.append(evaluation["component_error"])
    if evaluation["source_rc"] != expected["source_rc"]:
        issues.append("SOURCE_RC")
    if evaluation["source_stderr_bytes"] != 0:
        issues.append("SOURCE_STDERR")
    if not isinstance(actual, dict):
        issues.append("OUTPUT_NOT_OBJECT")
    else:
        value = dict(actual)
        if evaluation["source_stdout_bytes"] != 0:
            issues.append("SOURCE_STDOUT")
        if sha(canon(actual)) != evaluation["output"]["sha256"]:
            issues.append("NONCANONICAL_OUTPUT")
        if json.dumps(value, sort_keys=True, separators=(",", ":")) != json.dumps(expected["typed"], sort_keys=True, separators=(",", ":")):
            issues.append("FIXED_TYPED_RESULT_MISMATCH")
        if expected.get("decision_sha256") and evaluation["output"]["sha256"] != expected["decision_sha256"]:
            issues.append("FIXED_DECISION_SHA")
    return {"kind": "SYNTHETIC", "ATTRIBUTION": "ASSISTED", "label": evaluation["label"], "oracle_key": evaluation["oracle_key"], "source_rc": evaluation["source_rc"], "issues": issues, "decision_rc": 1 if issues else 0, "component_error": evaluation["component_error"], "fixed_oracle_match": not issues}


def capture_file(path, cap):
    if not path.exists():
        return None, {"path": str(path.relative_to(OUTPUT)).replace("\\", "/"), "present": False}
    st = path.lstat()
    need(stat.S_ISREG(st.st_mode) and not stat.S_ISLNK(st.st_mode), "OUTPUT_NONREGULAR")
    # Exact pinned core programs emit only their bounded JSON output. On any
    # unexpected oversized output preserve the file, hash all bytes in chunks,
    # and stop; never copy raw error text into a public receipt.
    digest = hashlib.sha256()
    kept = bytearray()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
            if len(kept) <= cap:
                kept.extend(chunk[:max(0, cap + 1 - len(kept))])
    need(identity(st) == identity(path.lstat()), "OUTPUT_CHANGED_AFTER_REAP")
    ref = {"path": str(path.relative_to(OUTPUT)).replace("\\", "/"), "present": True, "sha256": digest.hexdigest(), "bytes": st.st_size, "within_cap": st.st_size <= cap}
    return (bytes(kept) if st.st_size <= cap else None), ref


def run_case(case, old, oracle, stdin_handle, deadline):
    label = case["label"]
    need(type(label) is str and label and all(c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_" for c in label), "CASE_LABEL")
    folder = OUTPUT / "cases" / label
    folder.mkdir()
    source_raw, source_before = read_public(case["source"]["path"])
    input_raw, input_before = read_public(case["input"]["path"])
    need(sha(source_raw) == case["source"]["sha256"] and len(source_raw) == case["source"]["bytes"], "CASE_SOURCE_PIN")
    need(sha(input_raw) == case["input"]["sha256"] and len(input_raw) == case["input"]["bytes"], "CASE_INPUT_PIN")
    fixture = json.loads(input_raw)
    need(input_raw == canon(fixture) and input_raw.endswith(b"\n"), "FIXTURE_CANONICAL")
    need(case["abi"] == "core_cli_v1", "CORE_ONLY")
    remaining = deadline - time.monotonic()
    need(remaining > 0, "WHOLE_DEADLINE_BEFORE_CASE")
    timeout = min(CASE_SECONDS, remaining)
    output = folder / "COMPONENT.json"
    # cwd and input/source arguments use the relative public namespace. The
    # actual output is private execution evidence outside the public corpus.
    argv = [sys.executable, "-I", "-S", "-B", case["source"]["path"], "--request-json", input_raw[:-1].decode("utf-8"), "--allowed-requester-uid", "995", "--output", str(output)]
    emit(folder / "DISPATCH_INTENT.json", {"label": label, "source_sha256": sha(source_raw), "input_sha256": sha(input_raw), "state": "BEFORE_POPEN", "raw_streams_private": True})
    before_time = time.monotonic()
    child = None
    error = None
    dispatch_error = None
    rc = None
    reaped = False
    with (folder / "SOURCE.stdout").open("xb") as stdout, (folder / "SOURCE.stderr").open("xb") as stderr:
        try:
            child = subprocess.Popen(argv, cwd=PUBLIC, stdin=stdin_handle, stdout=stdout, stderr=stderr, shell=False, close_fds=True)
            try:
                rc = child.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                error = "COMPONENT_TIMEOUT"
            reaped = child.returncode is not None
        except Exception as exc:
            dispatch_error = type(exc).__name__
            error = error or "DISPATCH_OR_REAP_ERROR"
        finally:
            if child is not None and child.poll() is None:
                child.kill()
                try:
                    rc = child.wait(timeout=CLEANUP_SECONDS)
                except subprocess.TimeoutExpired:
                    error = "CHILD_NOT_REAPED"
                reaped = child.poll() is not None
            stdout.flush()
            stderr.flush()
            os.fsync(stdout.fileno())
            os.fsync(stderr.fileno())
    elapsed = time.monotonic() - before_time
    out_raw, out_ref = capture_file(output, FILE_CAP)
    stdout_raw, stdout_ref = capture_file(folder / "SOURCE.stdout", STREAM_CAP)
    stderr_raw, stderr_ref = capture_file(folder / "SOURCE.stderr", STREAM_CAP)
    source_after_raw, source_after = read_public(case["source"]["path"])
    input_after_raw, input_after = read_public(case["input"]["path"])
    unchanged = source_before == source_after and input_before == input_after and source_raw == source_after_raw and input_raw == input_after_raw
    actual = None
    if out_ref["present"]:
        try:
            actual = json.loads(out_raw) if out_raw is not None else None
            if out_raw is None:
                error = error or "OUTPUT_SIZE_CAP"
        except (ValueError, UnicodeError):
            error = error or "OUTPUT_JSON_INVALID"
    else:
        error = error or "OUTPUT_MISSING"
    if rc != 0:
        error = error or "COMPONENT_PROCESS_ERROR"
    actual_errors = actual.get("errors") if isinstance(actual, dict) else None
    if isinstance(actual_errors, list) and any(isinstance(e, str) and e.startswith("REQUEST_JSON:") for e in actual_errors):
        error = error or "COMPONENT_CAUGHT_EXCEPTION"
    evaluation = {"kind": "SYNTHETIC", "ATTRIBUTION": "ASSISTED", "label": label, "abi": "core_cli_v1", "oracle_key": case["oracle_key"], "actual": actual, "source_rc": rc, "component_error": error, "source_stdout_bytes": stdout_ref.get("bytes", 0), "source_stderr_bytes": stderr_ref.get("bytes", 0), "output": out_ref, "source_stdout": stdout_ref, "source_stderr": stderr_ref}
    grade = original_core_grade(evaluation, oracle)
    fields = {"label": label, "status": actual.get("state") if isinstance(actual, dict) else None, "errors": actual_errors, "target_error_present": case["target_error"] in actual_errors if isinstance(actual_errors, list) else False, "source_rc": rc, "grader_rc": grade["decision_rc"], "component_error": error, "fixed_oracle_match": grade["fixed_oracle_match"]}
    matched = all(fields[key] == old[key] for key in FIELD_KEYS)
    matched = matched and actual == old["typed_output"] and out_ref.get("sha256") == old["output_sha256"]
    matched = matched and stdout_raw == b"" and stderr_raw == b"" and unchanged and reaped and dispatch_error is None and elapsed <= CASE_SECONDS
    matched = matched and isinstance(actual, dict) and set(actual) == RESULT_KEYS and actual.get("actuation_performed") is False and actual.get("monetary_authority_present") is False
    evaluation_ref = emit(folder / "EVALUATION.json", evaluation)
    grade_ref = emit(folder / "GRADE.json", grade)
    summary = {"label": label, "reproduction_match": bool(matched), "baseline_oracle_match": grade["fixed_oracle_match"], "observed": fields, "evaluation": evaluation_ref, "grade": grade_ref, "source_before": source_before, "source_after": source_after, "input_before": input_before, "input_after": input_after, "source_sha256": sha(source_raw), "input_sha256": sha(input_raw), "source_and_input_unchanged": unchanged, "raw_files": [stdout_ref, stderr_ref, out_ref], "launched": child is not None, "child_reaped": reaped, "dispatch_error_type": dispatch_error, "elapsed_seconds": elapsed, "argv_projection": ["PINNED_CURRENT_PYTHON", "-I", "-S", "-B", case["source"]["path"], "--request-json", "EXACT_PINNED_FIXTURE_WITHOUT_FINAL_LF", "--allowed-requester-uid", "995", "--output", "FRESH_PRIVATE_CASE_COMPONENT_JSON"]}
    emit(folder / "CASE_RECEIPT.json", summary)
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["verify"])
    parser.add_argument("--manifest-sha256", required=True)
    args = parser.parse_args()
    need(len(args.manifest_sha256) == 64 and all(c in "0123456789abcdef" for c in args.manifest_sha256), "MANIFEST_PIN_ARGUMENT")
    started = time.monotonic()
    deadline = started + WHOLE_SECONDS
    OUTPUT.mkdir()
    (OUTPUT / "cases").mkdir()
    exclusive(OUTPUT / "STDIN.empty", b"")
    report = {"schema": "PORTABLE_PUBLIC_CORE24_CAPSULE_BUILD_RESULT_V1", "status": "HOLD", "scope": "SEPARATE_CAPSULE_BUILD_CORE24_ONLY", "kind": "SYNTHETIC", "ATTRIBUTION": "ASSISTED", "intended_cases": 24, "attempted_labels": [], "measured_cases": [], "unexecuted_labels": list(EXACT_LABELS), "first_false": None, "public_raw_export": False, "original_campaign_runs": 0, "full32_qualification": False, "linux_r3_OS_qualification": False, "operating_authority": False, "same_model_TMR": 0}
    manifest = None
    before = None
    stdin_before = None
    try:
        manifest_raw, manifest_identity = read_regular(ROOT / "BUILD_INPUTS.json")
        need(sha(manifest_raw) == args.manifest_sha256, "MANIFEST_PIN")
        manifest = json.loads(manifest_raw)
        need(set(manifest) == MANIFEST_KEYS, "BUILD_MANIFEST_FIELDS")
        need(manifest["schema"] == "PORTABLE_CORE24_BUILD_INPUTS_V1" and manifest["build_id"] == "PUBLIC_CORE24_BUILD_01" and manifest["mode"] == "SEPARATE_CAPSULE_BUILD_NOT_CAMPAIGN_RETRY", "BUILD_MANIFEST_SCHEMA")
        need(manifest["case_limit"] == 24 and manifest["whole_seconds"] == 60 and manifest["case_seconds"] == 5 and manifest["cleanup_seconds"] == 5, "BUILD_MANIFEST_LIMITS")
        need(manifest["status"] == "UNEXECUTED_CANDIDATE" and manifest["source_fixture_bytes_unchanged"] is True and manifest["full_campaign_cases"] == 32 and manifest["withheld_cases"] == 8 and manifest["os_profile"] == "PORTABLE_CURRENT_USER_PYTHON_NO_R3_INHERITANCE", "BUILD_MANIFEST_CLAIM_SCOPE")
        need(set(manifest["verifier"]) == {"path", "sha256", "bytes"} and manifest["verifier"]["path"] == "capsule_verify.py", "VERIFIER_REF_SCHEMA")
        own_raw, own_identity = read_regular(Path(__file__).resolve())
        need(sha(own_raw) == manifest["verifier"]["sha256"] and len(own_raw) == manifest["verifier"]["bytes"], "VERIFIER_PIN")
        before = snapshot(manifest)
        historical_raw, _ = read_public("BUILD_MANIFEST.inactive.json")
        need(sha(historical_raw) == manifest["original_public_manifest_sha256"], "HISTORICAL_PUBLIC_MANIFEST_PIN")
        historical = json.loads(historical_raw)
        need(historical["enabled"] is False and historical["new_capsule_builds"] == 0, "HISTORICAL_INPUT_STATUS_CHANGED")
        need(sorted(historical["files"], key=lambda x: x["path"]) == sorted([r for r in manifest["public_files"] if r["path"] != "BUILD_MANIFEST.inactive.json"], key=lambda x: x["path"]), "HISTORICAL_PUBLIC_FILES_JOIN")
        selection_raw, _ = read_public("SELECTION_CORE24.proposed.json")
        oracle_raw, _ = read_public("ORACLE_CORE.proposed.json")
        expected_raw, _ = read_public("EXPECTED_SELECTED32.proposed.json")
        selection, oracle, expected = map(json.loads, (selection_raw, oracle_raw, expected_raw))
        cases = selection["cases"]
        labels = [case["label"] for case in cases]
        need(len(labels) == len(set(labels)) == 24 and labels == manifest["exact_labels"] == EXACT_LABELS, "EXACT_CORE24_SELECTION")
        need(all(case["abi"] == "core_cli_v1" and case["rule"] in ("MONEY", "UID", "ROLLBACK") for case in cases), "CORE24_SCOPE")
        need(expected["selected_observations"] == 32 and expected["preselected_mutants"] == 12 and expected["denominators"] == manifest["full32_denominators"], "FULL32_DENOMINATORS_CHANGED")
        prior = {row[pol]["label"]: row[pol] for row in expected["rows"] for pol in ("PC", "NC")}
        need(len(prior) == 32 and all(label in prior for label in labels), "EXPECTED32_COVERAGE")
        report["unexecuted_labels"] = list(labels)
        emit(OUTPUT / "INPUTS_BEFORE.json", {"manifest_sha256": sha(manifest_raw), "manifest_identity": manifest_identity, "verifier_sha256": sha(own_raw), "verifier_identity": own_identity, "public_files": before})
        with (OUTPUT / "STDIN.empty").open("rb") as stdin_handle:
            stdin_before = identity(os.fstat(stdin_handle.fileno()))
            need(stat.S_ISREG(stdin_before["mode"]) and stdin_before["bytes"] == 0 and stdin_before == identity((OUTPUT / "STDIN.empty").lstat()), "EMPTY_REGULAR_STDIN")
            for case in cases:
                need(time.monotonic() < deadline, "WHOLE_DEADLINE")
                need(identity(os.fstat(stdin_handle.fileno())) == stdin_before, "STDIN_IDENTITY_CHANGED")
                report["attempted_labels"].append(case["label"])
                report["unexecuted_labels"].remove(case["label"])
                row = run_case(case, prior[case["label"]], oracle["cases"][case["oracle_key"]], stdin_handle, deadline)
                report["measured_cases"].append(row)
                need(row["reproduction_match"], "FIRST_UNEXPECTED_OBSERVATION")
            need(identity(os.fstat(stdin_handle.fileno())) == stdin_before, "STDIN_AFTER_CHANGED")
        after = snapshot(manifest)
        need(after == before, "FULL_INPUTS_CHANGED")
        need(read_regular(ROOT / "BUILD_INPUTS.json")[0] == manifest_raw and read_regular(Path(__file__).resolve())[0] == own_raw, "MANAGEMENT_INPUT_CHANGED")
        need(time.monotonic() <= deadline, "WHOLE_DEADLINE_AFTER_CASES")
        report["status"] = "PASS_REPRODUCED_PUBLIC_CORE24_ONLY"
    except Exception as exc:
        report["first_false"] = str(exc) if isinstance(exc, Stop) else type(exc).__name__
        report["status"] = "HOLD_FIRST_UNEXPECTED"
    finally:
        # Preserve completed prefix and all private raw evidence before final
        # adjudication. Error strings from source stderr are never printed.
        after = None
        after_error = None
        if manifest is not None:
            try:
                after = snapshot(manifest)
            except Exception as exc:
                after_error = str(exc) if isinstance(exc, Stop) else type(exc).__name__
        emit(OUTPUT / "INPUTS_AFTER.json", {"public_files": after, "error": after_error, "equal_before": after is not None and after == before})
        if after is None or after != before:
            report["status"] = "HOLD_FIRST_UNEXPECTED"
            report["first_false"] = report["first_false"] or "INPUT_POSTCHECK"
        report["measured_n"] = len(report["measured_cases"])
        report["unexecuted_n"] = len(report["unexecuted_labels"])
        report["attempted_n"] = len(report["attempted_labels"])
        report["attempts_without_complete_receipt"] = [label for label in report["attempted_labels"] if label not in {row["label"] for row in report["measured_cases"]}]
        report["confirmed_launched_n"] = sum(row["launched"] for row in report["measured_cases"])
        report["confirmed_not_launched_labels"] = [row["label"] for row in report["measured_cases"] if not row["launched"]]
        report["count_meaning"] = "measured_n counts completed observation receipts; confirmed_launched_n counts confirmed child starts. unexecuted_labels were never attempted. An attempt lacking a complete receipt is UNKNOWN, not target0."
        report["all_attempted_children_reaped"] = all(row["child_reaped"] for row in report["measured_cases"]) if not report["attempts_without_complete_receipt"] else None
        report["elapsed_seconds"] = time.monotonic() - started
        report["bounds"] = {"whole_dispatch_and_observation_seconds": WHOLE_SECONDS, "each_child_seconds": CASE_SECONDS, "owned_child_kill_reap_grace_seconds": CLEANUP_SECONDS, "cleanup_may_extend_wall_deadline": True, "retry": 0}
        report["raw_evidence_scope"] = "Private execution directory only; no automatic public copying. Success requires empty child stdout/stderr."
        report["independence"] = "Portable current-user Python reproduction; no Linux r3 confinement or independent-model credit."
        report["expected32_sha256"] = next((x["sha256"] for x in manifest["public_files"] if x["path"] == "EXPECTED_SELECTED32.proposed.json"), None) if manifest else None
        report["full32_denominators"] = manifest.get("full32_denominators") if manifest else None
        deterministic = {"schema": "PORTABLE_PUBLIC_CORE24_CONTENT_RECEIPT_V1", "status": report["status"], "manifest_sha256": args.manifest_sha256, "expected32_sha256": report["expected32_sha256"], "rows": [{"observed": row["observed"], "source_sha256": row["source_sha256"], "input_sha256": row["input_sha256"], "reproduction_match": row["reproduction_match"], "baseline_oracle_match": row["baseline_oracle_match"]} for row in report["measured_cases"]], "unexecuted_labels": report["unexecuted_labels"], "first_false": report["first_false"], "full32_qualification": False, "full32_denominators": report["full32_denominators"]}
        report["content_receipt"] = emit(OUTPUT / "CONTENT_RECEIPT.json", deterministic)
        emit(OUTPUT / "RESULT.json", report)
    ok = report["status"] == "PASS_REPRODUCED_PUBLIC_CORE24_ONLY"
    print(json.dumps({"status": report["status"], "measured_n": report["measured_n"], "unexecuted_n": report["unexecuted_n"], "first_false": report["first_false"]}, sort_keys=True))
    return 0 if ok else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Stop as exc:
        print(json.dumps({"status": "PREFLIGHT_HOLD", "first_false": str(exc)}, sort_keys=True))
        raise SystemExit(1)
    except Exception as exc:
        print(json.dumps({"status": "HOST_FILESYSTEM_HOLD", "first_false": type(exc).__name__}, sort_keys=True))
        raise SystemExit(1)
