# Core24 local reproduction artifact

This archive preserves an already completed local 24-case reproduction and its exact inputs.
It has not been published or independently reproduced on another machine.

From an extracted copy, select a Python interpreter and run this original command:

```text
cd candidate
python -I -S -B capsule_verify.py verify --manifest-sha256 3c5c9cf893d88eeae292095334408c953e555c10f09f9974440770d3d067030f
```

The verifier creates a fresh sibling `execution-01` directory at the extraction root.
That directory is deliberately absent from this ZIP. An existing directory refuses the run;
preserve it and use a separately extracted fresh copy for an explicitly chosen reproduction.
This README does not run or schedule anything.

The expected SHA-256 of the newly generated `execution-01/CONTENT_RECEIPT.json` is:

```text
687c6ea8ac2e073ea93101e3a88647b4d49125beb11905ca9af2e0dc1ec7757e
```

Compare its exact bytes with `reference/CONTENT_RECEIPT.json`. No path/time/PID-bearing private
RESULT or raw stdout/stderr is included. Physical observations from a reproduction remain private.

The closed reference reproduces 24 of 24 prior observations. The unchanged original baseline
oracle matches 12 and mismatches 12. Reproducing a mismatch is not baseline acceptance.
The eight motor cases are withheld, so this is not full32 qualification. The original 12-mutant,
two-behavioral-detection table is historical context, not a newly measured detector score.

`candidate/README_BUILD.md`, `candidate/BUILD_INPUTS.json`, and the inactive/expected32 files
under `candidate/public` retain their exact historical preparation bytes. Their inactive,
proposed or unexecuted labels describe their creation generation; this root README and the
reference receipt distinguish the later closed build without rewriting those inputs.

`FILES.sha256.json` lists the 38 payload members with size, SHA-256 and CRC32. It excludes itself
to avoid a self-hash cycle; the external package receipt binds its hash and the complete ZIP.
The packaging process verifies every ZIP member after writing and checks all CRCs.

Original license/attribution files remain under `candidate/public/upstream-v1`. No source,
fixture or license bytes are changed and no additional rights, certification, operating
authority, trading qualification or inherited r3 isolation is asserted.
